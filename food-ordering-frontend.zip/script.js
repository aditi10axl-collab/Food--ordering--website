const menu = [
  { name: "Paneer Tikka", price: 120, img: "https://via.placeholder.com/200x150?text=Paneer+Tikka" },
  { name: "Veg Biryani", price: 150, img: "https://via.placeholder.com/200x150?text=Veg+Biryani" },
  { name: "Cheese Pizza", price: 180, img: "https://via.placeholder.com/200x150?text=Pizza" },
  { name: "Cold Coffee", price: 90, img: "https://via.placeholder.com/200x150?text=Coffee" }
];

const menuItemsDiv = document.getElementById("menuItems");

menu.forEach(item => {
  const card = document.createElement("div");
  card.className = "card";
  card.innerHTML = `
    <img src="${item.img}" alt="${item.name}">
    <h3>${item.name}</h3>
    <p>₹${item.price}</p>
    <button onclick="addToCart('${item.name}', ${item.price})">Add to Cart</button>
  `;
  menuItemsDiv.appendChild(card);
});

function addToCart(name, price) {
  let cart = JSON.parse(localStorage.getItem("cart")) || [];
  cart.push({ name, price });
  localStorage.setItem("cart", JSON.stringify(cart));
  alert(`${name} added to cart!`);
}
